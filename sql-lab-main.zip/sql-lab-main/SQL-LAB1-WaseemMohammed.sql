--Category 1: Understanding the Landscape of College 
--Basketball (Questions 1-15) 
--These questions help students explore and understand the structure, organization, and basic 
--characteristics of college basketball data. 
/*Tables
mbb_teams_games_sr 
mbb_teams 
mbb_players_games_sr 
mascots 
team_colors
*/
--Basic Structure & Organization (1-8) 
--1. All Team Information - "Display all information for the first 10 teams in the database." 

SELECT *
FROM `bigquery-public-data.ncaa_basketball.mbb_teams`
LIMIT 10;

--2. Unique Conferences - "Find all unique conference names that exist in the database." 

SELECT DISTINCT conf_name
FROM `bigquery-public-data.ncaa_basketball.mbb_teams`;

--3. Teams in Alphabetical Order - "List all team markets in alphabetical order." 

SELECT market
FROM `bigquery-public-data.ncaa_basketball.mbb_teams`
ORDER BY 1 ASC;

--4. First Five Teams - "Show the first 5 teams when ordered by team name." 

SELECT DISTINCT name AS team_name
FROM `bigquery-public-data.ncaa_basketball.mbb_teams`
ORDER BY 1 ASC
LIMIT 5;

--5. Basic Team Details - "Display only the market, name, and conference name for all teams." 

SELECT 
  market,
  name AS team_name,
  conf_name as conference
FROM `bigquery-public-data.ncaa_basketball.mbb_teams`
ORDER BY 1 ASC;

--6. Venue States - "Find all unique venue states and display them in alphabetical order." 

SELECT DISTINCT venue_state
FROM `bigquery-public-data.ncaa_basketball.mbb_teams`
ORDER BY 1 ASC;

--7. Team Colors Sample - "Show the market and color information for 15 teams." 

SELECT market,
  color as team_color
FROM `bigquery-public-data.ncaa_basketball.team_colors`
LIMIT 15;


--8. Mascot Information - "Display the market, mascot, and mascot name for the first 10 teams."

SELECT 
  market,
  mascot,
  mascot_name,
FROM `bigquery-public-data.ncaa_basketball.mascots`
LIMIT 10;

--Conference & Team Organization (9-15) 
--9. Big Ten Teams - "Find all teams that belong to the Big Ten conference." 

SELECT 
  name AS team_name,
  conf_name as conference
FROM `bigquery-public-data.ncaa_basketball.mbb_teams`
WHERE conf_name = 'Big Ten';


--10. Tournament Games - "Find all games between 2014-2016 that were part of any tournament." 

SELECT 
  game_id,
  season,
  scheduled_date,
  tournament,
  tournament_type
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE season BETWEEN 2014 AND 2016 AND tournament IS NOT NULL
ORDER BY 3 ASC;


--11. State Schools - "Find all teams where the market name contains the word 'State'." 

SELECT 
  market,
  name as team_name
FROM `bigquery-public-data.ncaa_basketball.mbb_teams`
WHERE market LIKE '%State%';

--12. Power Conferences - "Find all teams that belong to the ACC, SEC, or Big 12 conferences." 

SELECT 
  name as team_name,
  conf_name,
  conf_alias
FROM `bigquery-public-data.ncaa_basketball.mbb_teams`
WHERE conf_name LIKE '%ACC%'OR conf_name LIKE '%SEC%'OR conf_name LIKE '%Big 12%'
      OR conf_alias LIKE '%ACC%'OR conf_alias LIKE '%SEC%'OR conf_alias LIKE '%Big 12%';


--13. Teams Per Conference - "Count how many teams belong to each conference." 

SELECT 
  conf_name AS conference,
  count(*) AS num_of_teams
FROM `bigquery-public-data.ncaa_basketball.mbb_teams`
GROUP BY 1;

--14. Large Conferences - "Find conferences that have more than 10 teams."

SELECT 
  conf_name AS conference,
  count(*) AS num_of_teams
FROM `bigquery-public-data.ncaa_basketball.mbb_teams`
GROUP BY 1
HAVING num_of_teams >= 10;

--15. Conference Regional Groups - "Group conferences into regions and count teams in each region." 

--Categories for regions: 
--● East: "Eastern Region" (ACC, Big East, Colonial Athletic Association) 
--● Midwest: "Midwest Region" (Big Ten, Big 12) 
--● West: "Western Region" (Pac-12, Mountain West) 
--● Other: "Other Regions" (all other conferences) 

SELECT 
  CASE
    WHEN conf_name IN ('ACC', 'Big East', 'Colonial Athletic Association') THEN 'Eastern Region'
    WHEN conf_name IN ('Big Ten', 'Big 12')THEN 'Midwest Region'
    WHEN conf_name IN ('Pac-12', 'Mountain West')THEN 'Western Region'
    ELSE 'Other Regions'
  END AS Regions,
  count(name) AS num_of_teams
FROM `bigquery-public-data.ncaa_basketball.mbb_teams`
GROUP BY 1;

/*Category 2: Deep Diving into Performance (Questions 16-30) 
These questions focus on analyzing game performance, attendance patterns, and team/venue 
characteristics using aggregation and joins. 
*/

--Game Performance & Attendance Analysis (16-24) 
--16. High Attendance Games - "Find all games in 2016 that had attendance greater than 15,000." 

SELECT 
  game_id,
  attendance,
  season,
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE attendance > 15000 AND season = 2016;

--17. Total Teams - "Count the total number of teams in the database." 

SELECT 
  count(DISTINCT name) AS total_teams
FROM `bigquery-public-data.ncaa_basketball.mbb_teams`;

--18. Highest Attendance 2015 - "Find the highest attendance recorded for any game in 2015." 

SELECT 
  MAX(attendance) as max_attendance
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE season = 2015;

--19. Lowest Attendance 2014 - "Find the lowest attendance recorded for any game in 2014 (excluding null values)." 

SELECT 
  MIN(attendance) as min_attendance
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE season = 2014;

--20. Average Attendance 2015 - "Calculate the average attendance for all games in 2015." 

SELECT 
  ROUND(AVG(attendance),1) as avg_attendance
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE season = 2015;

--21. Total Attendance 2016 - "Calculate the total attendance across all games in 2016." 

SELECT 
  SUM(attendance) as sum_attendance
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE season = 2016;

--22. Tournament Game Count - "Count how many tournament games were played in 2015." 

SELECT 
  COUNT(game_id) as total_games
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE season = 2015;

--23. Unique Venues 2014 - "Count how many different venues were used during the 2014 season." 

SELECT 
  COUNT(DISTINCT venue_id) as total_venues
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE season = 2014;

--24. Attendance Statistics 2016 - "Show the minimum, maximum, and average attendance for games in 2016." 

SELECT 
  MAX(attendance) as max_attendance,
  MIN(attendance) as min_attendance,
  AVG(attendance) as avg_attendance,
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE season = 2016;

--Seasonal & Temporal Analysis (25-30) 

--25. Home Games in 2015 - "Find all home games played during the 2015 season." 

SELECT *
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE season = 2015 AND home_team = true;

--26. January 2015 Games - "Find all games that were scheduled in January 2015." 

SELECT game_id,
  scheduled_date
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE EXTRACT(MONTH FROM scheduled_date) = 01 AND season = 2015;

--27. Conference Games in 2014 - "Find all conference games played during the 2014 season." 

SELECT game_id,
  conf_name,
  conf_id,
  scheduled_date
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE season = 2014;

--28. Games Per Season - "Count the number of games played in each season from 2014-2016." 

SELECT season,
  COUNT(game_id) AS num_of_games
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE season BETWEEN 2014 AND 2016
GROUP BY 1
ORDER BY 1 ASC;

--29. Games by Month - "Count how many games were played in each month during 2015." 

WITH months_table AS(
  SELECT 
    season,
    EXTRACT(MONTH FROM scheduled_date) AS months
  FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
  WHERE season=2015
)
SELECT 
  months,
  COUNT(*)
FROM months_table
GROUP BY 1;

--30. Weekend Games - "Find all games played on weekends (Saturday or Sunday) in 2016." 

SELECT game_id, scheduled_date
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE (EXTRACT(YEAR FROM scheduled_date) = 2016) AND (EXTRACT(DAYOFWEEK FROM scheduled_date) = 1 OR EXTRACT(DAYOFWEEK FROM scheduled_date) = 7);

--Category 3: Advanced Analytics (Questions 31-45) 
--These questions perform sophisticated analysis using CTEs, complex joins, case logic, and comparative analytics to derive deeper insights. 
--Team & Conference Comparative Analysis (31-37) 

--31. Teams with Colors - "Show each team's market, name, and team color." 

SELECT 
  m.market,
  m.name,
  c.color
FROM `bigquery-public-data.ncaa_basketball.mbb_teams` m
JOIN `bigquery-public-data.ncaa_basketball.team_colors` c 
ON m.id=c.id;


--32. Teams with Mascots - "Show all teams and their mascots, including teams without mascot information." 

SELECT 
  t.market,
  t.name,
  m.mascot,
  m.mascot_name
FROM `bigquery-public-data.ncaa_basketball.mbb_teams` t
LEFT JOIN `bigquery-public-data.ncaa_basketball.mascots` m 
ON t.id=m.id;

--33. Formatted Game Dates - "Display game dates in 'Month YYYY' format for games in 2014." 

SELECT 
  game_id,
  scheduled_date,
  FORMAT_DATE('%b %Y', scheduled_date)
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE EXTRACT(YEAR FROM scheduled_date) = 2014;

--34. Average Attendance as Float - "Calculate the average attendance for 2015 games, casting attendance as a decimal number." 

SELECT 
  AVG(CAST(attendance AS FLOAT64)) AS avg_attendance
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE EXTRACT(YEAR FROM scheduled_date) = 2015;

--35. CTE - High Performing Conference Teams - "Find teams that had above-average attendance compared to other teams in their same conference during 2015." 

WITH TB1 AS (
  SELECT
    conf_id as id,
    name as team_name,
    conf_name as conference,
    AVG(attendance) AS avg_attendance
  FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
  GROUP BY 1, 2, 3
),

TB2 AS(
SELECT 
  TB1.team_name,
  TB1.conference,
  TB1.avg_attendance,
  g.attendance
FROM TB1
JOIN `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr` g
 ON g.conf_id = TB1.id
WHERE EXTRACT(YEAR FROM scheduled_date) = 2015
)

SELECT *
FROM TB2
WHERE attendance > avg_attendance
ORDER BY attendance DESC;



--36. CTE - High Activity Teams - "Find teams that played more than 30 games in 2015 and show their full team information." 

WITH TB1 AS (
  SELECT
    name AS team_name,
    COUNT(game_id) AS num_of_games
  FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
  WHERE EXTRACT(YEAR FROM scheduled_date) = 2015
  GROUP BY 1
)

SELECT 
  TB1.team_name,
  TB1.num_of_games
FROM TB1
WHERE TB1.num_of_games>30 ;

--37. CTE - Most Active Conferences - "Find the top 5 conferences with the most games played from 2014-2016." 

WITH TB1 AS (
  SELECT
    conf_name AS conferences,
    COUNT(game_id) AS num_of_games
  FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
  WHERE EXTRACT(YEAR FROM scheduled_date) BETWEEN 2014 AND 2016
  GROUP BY 1
)

SELECT 
  TB1.conferences,
  TB1.num_of_games
FROM TB1
ORDER BY 2 DESC 
LIMIT 5;

--Performance Categorization & Classification (38-42) 
--38. Attendance Size Categories - "Categorize games in 2015 by their attendance size and count each category." 

--Categories for attendance size: 
--● Small: "Small Crowd" (attendance < 5,000) 
--● Medium: "Medium Crowd" (attendance 5,000-15,000) 
--● Large: "Large Crowd" (attendance > 15,000) 
--● Unknown: "Unknown Size" (null attendance) 

SELECT 
  CASE 
    WHEN attendance <5000 then 'Small Crowd'
    WHEN attendance <15000 then 'Medium Crowd'
    WHEN attendance >5000 then 'Large Crowd'
    ELSE'Unknown Size'
  END AS attendance_size,
  COUNT(attendance) AS num_of_occurence
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE EXTRACT(YEAR FROM scheduled_date) = 2015
GROUP BY 1;

--39. Home Attendance Performance - "Categorize teams by their home game attendance performance from 2014-2016." 

--Categories for performance: 
--● High: "High Attendance" (average home attendance > 10,000) 
--● Medium: "Medium Attendance" (average home attendance 5,000-10,000) 
--● Low: "Low Attendance" (average home attendance < 5,000) 

SELECT 
  CASE 
    WHEN attendance >10000 then 'High Attendance'
    WHEN attendance >5000 then 'Medium Attendance'
    ELSE 'Low Attendance'
  END AS attendance_size,
  COUNT(attendance) num_of_occurence
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE (home_team = true) AND (EXTRACT(YEAR FROM scheduled_date) BETWEEN 2014 AND 2016)
GROUP BY 1;

--40. Tournament Participation - "Categorize teams by their tournament participation from 2014-2016 and count by season." 

--Categories for participation: 
--● NCAA: "NCAA Tournament" (tournament = 'NCAA') 
--● Other: "Other Tournament" (tournament not null but not 'NCAA') 
--● None: "No Tournament" (tournament is null) 

SELECT 
  CASE 
    WHEN tournament = 'NCAA' then 'NCAA Tournament'
    WHEN tournament <> 'NCAA' AND tournament IS NOT NULL then 'Medium Attendance'
    ELSE 'No Tournament'
  END AS tournament_participation,
  COUNT(season) num_of_seasons
FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
WHERE EXTRACT(YEAR FROM scheduled_date) BETWEEN 2014 AND 2016
GROUP BY 1;


--41. CTE - Top Scoring Teams - "Find teams that scored above their conference average in 2015 using a CTE to calculate conference averages first." 

WITH TB1 AS (
  SELECT
    conf_id as id,
    conf_name AS conferences,
    AVG(points) AS avg_points
  FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
  GROUP BY 1, 2
),

TB2 AS(
SELECT 
  TB1.conferences,
  TB1.avg_points,
  AVG(g.points) AS above_avg
FROM TB1
JOIN `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr` g
 ON g.conf_id = TB1.id
WHERE (EXTRACT(YEAR FROM scheduled_date) = 2015)
GROUP BY 1 ,2
ORDER BY 2 DESC
)

SELECT *
FROM TB2
WHERE above_avg > TB2.avg_points
ORDER BY TB2.above_avg DESC;

--42. CTE - Popular Venue Analysis - "Find venues that have higher attendance than the average attendance of venues in their same state using a CTE derived table."

WITH TB1 AS (
  SELECT
    conf_id as id,
    venue_state,
    AVG(attendance) AS avg_attendance
  FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
  GROUP BY 1, 2
),

TB2 AS(
SELECT 
  g.venue_name,
  TB1.venue_state,
  g.attendance,
  TB1.avg_attendance,
FROM TB1
JOIN `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr` g
 ON g.conf_id = TB1.id
WHERE g.attendance >TB1.avg_attendance
ORDER BY 2 DESC
)

SELECT *
FROM TB2
WHERE attendance > avg_attendance
ORDER BY attendance DESC;

--Advanced Multi-Dimensional Analysis (43-45) 
--43. CTE - Conference Tournament Leaders - "Find the team in each conference that played the most tournament games from 2014-2016 using a CTE to first calculate tournament games per team." 

WITH T1 AS(
  SELECT
    name AS team_name,
    COUNT(*) AS total_games
  FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
  WHERE tournament IS NOT NULL
  GROUP BY 1
),

T2 AS(
  SELECT
    T1.team_name,
    g.conf_name,
    MAX(total_games) AS total_conf_touranment_games,
    COUNT(*) AS total_games
  FROM T1
  JOIN `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr` g
  ON g.name = T1.team_name
  WHERE EXTRACT(YEAR FROM scheduled_date) BETWEEN 2014 AND 2016
  GROUP BY 1,2
)

SELECT *
FROM T2
ORDER BY total_conf_touranment_games DESC;


--44. CTE - Top Player Minutes - "Find players who averaged more than 20 minutes per game in 2015 using a CTE derived table to calculate player averages first." 


WITH T1 AS (
  SELECT
    p.player_id,
    p.full_name AS player,
    AVG(CAST(p.minutes_int64 AS INT64)) AS avg_minutes
  FROM `bigquery-public-data.ncaa_basketball.mbb_players_games_sr` p
  JOIN `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr` g
    ON p.game_id = g.game_id
  WHERE EXTRACT(YEAR FROM g.scheduled_date) = 2015
  GROUP BY 1, 2
)

SELECT *
FROM T1
WHERE T1.avg_minutes > 20;


--45. CTE - Season Comparison Analysis - "Compare each team's 2015 performance to their 2014 performance by using a CTE to calculate season statistics first, then joining the results."

WITH T1 AS(
  SELECT 
    game_id AS id,
    name AS team_name,
    points AS points1,
    AVG(points) AS avg_points
  FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
  WHERE season = 2015
  GROUP BY 1,2,3
),

T2 AS(
  SELECT 
    game_id AS id,
    name AS team_name,
    points AS points2,
    AVG(points) AS avg_points
  FROM `bigquery-public-data.ncaa_basketball.mbb_teams_games_sr`
  WHERE season = 2014
  GROUP BY 1,2,3
)

SELECT 
  T1.team_name,
  T1.points1 AS points_2015,
  T1.avg_points AS points_avg_2015,
  T2.points2 AS points_2014,
  T2.avg_points AS points_avg_2014
FROM T1
LEFT JOIN T2
  ON T2.id = T1.id

