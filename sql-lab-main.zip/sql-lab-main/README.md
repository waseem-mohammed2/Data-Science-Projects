# sql-lab

Solution for SQL lab



sample read meee- first read then know



